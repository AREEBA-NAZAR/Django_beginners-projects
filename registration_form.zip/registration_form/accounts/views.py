from django.shortcuts import render
from django.contrib import messages
# Create your views here.
from .forms import SignupForm ,edituserform
from django.contrib.auth.forms import AuthenticationForm , PasswordChangeForm
from django.contrib.auth import authenticate , login ,logout
from django.http import HttpResponseRedirect
from django.contrib.auth import update_session_auth_hash

def sign_up(request):
    if request.method =="POST":
        fm = SignupForm(request.POST)
        if fm.is_valid():
            messages.success(request ,"Account created Sucessfully")
            fm.save()
    else:
        fm = SignupForm()

    return render(request , 'accounts/signup.html' , {'form' : fm})
    

def user_login(request):
    if request.method =="POST":
      fm=AuthenticationForm(request=request , data=request.POST)
      if fm.is_valid():
          usename=fm.cleaned_data['username']
          usepassword=fm.cleaned_data['password']
          user = authenticate(username=usename ,password =usepassword)
          if user is not None:
              login(request ,user) 
              messages.success(request, "Login sucessfully!")
              return HttpResponseRedirect('/profile/')
    fm = AuthenticationForm()
    return render(request , 'accounts/userlogin.html' , {'form' : fm})



def user_profile(request):
    if request.user.is_authenticated:
        if request.method == 'POST':
            fm = edituserform(request.POST , instance = request.user)
            if fm.is_valid():
             messages.success(request , 'Profile updated')
             fm.save()   
        else:
            fm = edituserform(instance= request.user)
        return render(request , 'accounts/profile.html' , {'name': request.user , 'form':fm}) 
    else:
        return HttpResponseRedirect('/login/')

def user_logout(request):
    logout(request)
    return HttpResponseRedirect("/login/")

def user_change_pass(request):
    if request.user.is_authenticated:
        if request.method == "POST":
            fm = PasswordChangeForm(user=request.user , data=request.POST)
            if fm.is_valid():
                fm.save()
                update_session_auth_hash(request , fm.user)
                messages.success(request , " passward changed sucessfully!")
                return HttpResponseRedirect('/profile/')
        else:
            fm = PasswordChangeForm(user=request.user) 
            return render(request , 'accounts/changepass.html' , {'form':fm})
    else:
        return HttpResponseRedirect('/login/')